"""Streamlit UI.  Run: streamlit run app.py"""
import streamlit as st
from src.config import CHOICES, MODEL_PATH, REPORT_DIR
from src.predict import predict, prevention_advice, risk_band

st.set_page_config(page_title="Road Accident Severity Predictor", page_icon="🚧", layout="wide")
st.title("🚧 Road Accident Severity Predictor")
st.caption("Describe the accident conditions -> predicted severity, risk score, and how it could have been prevented.")

if not MODEL_PATH.exists():
    st.error("No trained model found. Run `python -m src.train` first."); st.stop()

tab1, tab2 = st.tabs(["Predict & Prevent", "Model insights"])

with tab1:
    c1, c2, c3 = st.columns(3)
    with c1:
        st.subheader("Road & environment")
        road_type = st.selectbox("Road type", CHOICES["road_type"])
        area_type = st.selectbox("Area", CHOICES["area_type"])
        junction = st.selectbox("Junction", CHOICES["junction"])
        weather = st.selectbox("Weather", CHOICES["weather"])
        road_surface = st.selectbox("Road surface", CHOICES["road_surface"])
        light = st.selectbox("Light condition", CHOICES["light_condition"])
    with c2:
        st.subheader("Vehicle & driver")
        vehicle = st.selectbox("Vehicle type", CHOICES["vehicle_type"])
        age = st.slider("Driver age", 16, 90, 30)
        limit = st.select_slider("Speed limit (km/h)", [20, 30, 40, 50, 60, 80, 100, 120], 60)
        speed = st.slider("Actual speed (km/h)", 5, 180, 60)
        nveh = st.slider("Vehicles involved", 1, 5, 2)
    with c3:
        st.subheader("Time & behaviour")
        hour = st.slider("Hour of day", 0, 23, 18)
        dow = st.selectbox("Day", range(7), format_func=lambda i: "Mon Tue Wed Thu Fri Sat Sun".split()[i])
        alcohol = st.checkbox("Alcohol involved")
        belt = st.checkbox("Seatbelt / helmet worn", value=True)
        ped = st.checkbox("Pedestrian involved")

    case = dict(road_type=road_type, weather=weather, light_condition=light, road_surface=road_surface,
                vehicle_type=vehicle, area_type=area_type, junction=junction, speed_limit=limit,
                actual_speed=speed, num_vehicles=nveh, driver_age=age, hour=hour, day_of_week=dow,
                alcohol_involved=int(alcohol), seatbelt_or_helmet=int(belt), pedestrian_involved=int(ped))

    if st.button("Predict severity", type="primary"):
        r = predict(case)
        m1, m2, m3 = st.columns(3)
        m1.metric("Predicted severity", r["label"])
        m2.metric("Severity index (0-100)", r["severity_index"])
        m3.metric("Risk band", risk_band(r["severity_index"]))
        st.bar_chart(r["probabilities"])
        st.subheader("How could this have been less severe?")
        for s in prevention_advice(case):
            st.write(f"**-{s['reduction']} pts** -> {s['action']} (index becomes {s['new_index']})")

with tab2:
    for f, title in [("feature_importance.png", "What drives severity"), ("confusion_matrix.png", "Confusion matrix")]:
        if (REPORT_DIR / f).exists():
            st.subheader(title); st.image(str(REPORT_DIR / f))
