# Road Accident Severity Prediction

Predicts how severe a road accident is (**Minor / Serious / Fatal**, plus a 0-100
severity index) and runs a **counterfactual "best case" analysis** showing which
changes (speed, seatbelt/helmet, alcohol, lighting, road surface, junction design)
would have reduced the severity the most.

## Quick start
```bash
pip install -r requirements.txt
python -m src.train          # generates data (if missing), trains, saves model + plots
python -m src.predict        # CLI demo with an example crash
streamlit run app.py         # web UI
```

## Pipeline
| Step | File | What it does |
|---|---|---|
| Data | `src/data.py` | Loads `data/accidents.csv`; creates a synthetic dataset if absent |
| Train | `src/train.py` | Gradient boosting + class weighting (fatal crashes are rare), metrics, confusion matrix, permutation importance |
| Predict | `src/predict.py` | Probabilities, severity index, prevention what-if engine |
| UI | `app.py` | Streamlit app |

## Using REAL data (important)
The bundled data is **synthetic** (built from known risk relationships), so the
reported scores only prove the pipeline works - not real-world accuracy.
Replace `data/accidents.csv` with a real dataset mapped to the same columns
(`severity` = 0/1/2):
- UK **STATS19** (data.gov.uk) - closest match to this schema
- Kaggle **US Accidents**, **India road accidents (MoRTH / state police)**
Missing columns (e.g. `actual_speed`) can be dropped from `config.py` FEATURES.

## Design notes
- **Imbalance:** Fatal is ~3-4% of cases -> `class_weight="balanced"`, evaluated by macro-F1 and fatal recall, not accuracy.
- **Severity index:** `0*P(minor) + 40*P(serious) + 100*P(fatal)` - one comparable number.
- **Prevention:** model-based counterfactuals show *association learned from data*, not proven causation; use for guidance, not legal conclusions.

## Ideas to extend
SHAP explanations, hotspot map (lat/lon clustering), time-series of risk by hour,
SMOTE/cost-sensitive tuning, API (FastAPI), model monitoring.
