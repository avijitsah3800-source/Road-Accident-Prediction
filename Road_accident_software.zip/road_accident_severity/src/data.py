"""Data loading + a realistic synthetic generator.

Real data: any CSV with the columns in config.FEATURES + `severity`
(0=Minor, 1=Serious, 2=Fatal) works. For public datasets (UK STATS19,
US Accidents, India MoRTH) write a small mapper into this schema - see README.
The synthetic generator lets the whole pipeline run offline.
"""
import numpy as np
import pandas as pd
from .config import CHOICES, DATA_PATH, TARGET, FEATURES


def add_derived(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["is_night"] = ((df["hour"] >= 20) | (df["hour"] < 6)).astype(int)
    df["is_rush_hour"] = df["hour"].isin([8, 9, 17, 18, 19]).astype(int)
    df["is_weekend"] = (df["day_of_week"] >= 5).astype(int)
    return df


def generate_synthetic(n: int = 20000, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    def pick(k, w):
        w = np.array(w, dtype=float)
        return rng.choice(CHOICES[k], n, p=w / w.sum())

    df = pd.DataFrame({
        "road_type": pick("road_type", [50, 20, 10, 12, 8]),
        "weather": pick("weather", [65, 22, 5, 3, 5]),
        "light_condition": pick("light_condition", [60, 25, 15]),
        "road_surface": pick("road_surface", [68, 24, 5, 3]),
        "vehicle_type": pick("vehicle_type", [50, 18, 10, 4, 6, 12]),
        "area_type": pick("area_type", [62, 38]),
        "junction": pick("junction", [50, 20, 18, 12]),
        "speed_limit": rng.choice([20, 30, 40, 50, 60, 80, 100, 120], n,
                                  p=[.04, .28, .12, .14, .16, .08, .10, .08]),
        "num_vehicles": rng.choice([1, 2, 3, 4, 5], n, p=[.25, .50, .15, .07, .03]),
        "driver_age": np.clip(rng.normal(37, 14, n), 17, 90).astype(int),
        "hour": rng.integers(0, 24, n),
        "day_of_week": rng.integers(0, 7, n),
        "alcohol_involved": (rng.random(n) < 0.08).astype(int),
        "pedestrian_involved": (rng.random(n) < 0.12).astype(int),
    })
    df["actual_speed"] = np.clip(df["speed_limit"] * rng.normal(1.0, 0.22, n), 5, 180).round()
    df["seatbelt_or_helmet"] = (rng.random(n) < np.where(
        df["vehicle_type"].isin(["Motorcycle", "Bicycle"]), 0.70, 0.88)).astype(int)
    df = add_derived(df)

    # ---- latent risk score (domain-inspired relationships) ----
    over = np.clip(df["actual_speed"] - df["speed_limit"], 0, None)
    risk = (
        0.035 * df["actual_speed"] + 0.04 * over
        + 1.1 * df["alcohol_involved"]
        - 1.0 * df["seatbelt_or_helmet"]
        + 1.3 * df["pedestrian_involved"]
        + 0.6 * df["is_night"]
        + 0.5 * (df["light_condition"] == "Dark - unlit")
        + df["weather"].map({"Clear": 0, "Rain": .2, "Fog": .5, "Snow": .4, "High winds": .2})
        + df["road_surface"].map({"Dry": 0, "Wet": .25, "Icy": .5, "Flooded": .3})
        + df["vehicle_type"].map({"Car": 0, "Motorcycle": 1.1, "Truck": .5, "Bus": .3,
                                  "Bicycle": .9, "Auto-rickshaw": .6})
        + 0.5 * (df["area_type"] == "Rural")
        + df["road_type"].map({"Single carriageway": .2, "Dual carriageway": .1, "Motorway": .4,
                               "Roundabout": -.3, "Slip road": 0})
        + 0.5 * (df["driver_age"] > 65) + 0.5 * (df["driver_age"] < 22)
        + 0.1 * (df["num_vehicles"] - 1)
    )
    risk = risk + rng.normal(0, 0.9, n)
    lo, hi = np.quantile(risk, [0.72, 0.965])   # ~72% minor, ~24% serious, ~3.5% fatal
    df[TARGET] = np.select([risk >= hi, risk >= lo], [2, 1], default=0)
    return df


def load_data(path=DATA_PATH) -> pd.DataFrame:
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        generate_synthetic().to_csv(path, index=False)
        print(f"[data] synthetic dataset written to {path}")
    df = pd.read_csv(path)
    missing = set(FEATURES + [TARGET]) - set(df.columns)
    if missing:
        raise ValueError(f"CSV missing columns: {missing}")
    return df
