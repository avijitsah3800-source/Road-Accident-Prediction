"""Train, evaluate and save the severity model.  Run: python -m src.train"""
import json
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.inspection import permutation_importance
from sklearn.metrics import (ConfusionMatrixDisplay, classification_report,
                             f1_score, recall_score)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OrdinalEncoder

from .config import (CATEGORICAL, FEATURES, MODEL_PATH, NUMERIC, REPORT_DIR,
                     SEVERITY_LABELS, TARGET)
from .data import load_data


def build_pipeline() -> Pipeline:
    pre = ColumnTransformer([
        ("cat", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1), CATEGORICAL),
        ("num", "passthrough", NUMERIC),
    ])
    cat_mask = [True] * len(CATEGORICAL) + [False] * len(NUMERIC)
    clf = HistGradientBoostingClassifier(
        max_iter=300, learning_rate=0.06, max_depth=6, l2_regularization=1.0,
        categorical_features=cat_mask, class_weight="balanced", random_state=42)
    return Pipeline([("pre", pre), ("clf", clf)])


def main():
    REPORT_DIR.mkdir(exist_ok=True)
    df = load_data()
    X, y = df[FEATURES], df[TARGET]
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

    model = build_pipeline().fit(Xtr, ytr)
    pred = model.predict(Xte)
    names = [SEVERITY_LABELS[i] for i in sorted(SEVERITY_LABELS)]

    print(classification_report(yte, pred, target_names=names))
    metrics = {
        "macro_f1": round(f1_score(yte, pred, average="macro"), 4),
        "weighted_f1": round(f1_score(yte, pred, average="weighted"), 4),
        "fatal_recall": round(recall_score(yte, pred, labels=[2], average="macro"), 4),
    }

    fig, ax = plt.subplots(figsize=(5, 4.5))
    ConfusionMatrixDisplay.from_predictions(yte, pred, display_labels=names,
                                            cmap="Blues", ax=ax, colorbar=False)
    ax.set_title("Confusion matrix (test set)")
    fig.tight_layout(); fig.savefig(REPORT_DIR / "confusion_matrix.png", dpi=140); plt.close(fig)

    imp = permutation_importance(model, Xte, yte, scoring="f1_macro",
                                 n_repeats=5, random_state=42, n_jobs=-1)
    order = np.argsort(imp.importances_mean)
    fig, ax = plt.subplots(figsize=(7, 6))
    ax.barh(np.array(FEATURES)[order], imp.importances_mean[order], color="#c0392b")
    ax.set_title("What drives accident severity? (permutation importance)")
    ax.set_xlabel("Drop in macro-F1 when feature is shuffled")
    fig.tight_layout(); fig.savefig(REPORT_DIR / "feature_importance.png", dpi=140); plt.close(fig)
    metrics["top_factors"] = [FEATURES[i] for i in order[::-1][:6]]

    MODEL_PATH.parent.mkdir(exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    (REPORT_DIR / "metrics.json").write_text(json.dumps(metrics, indent=2))
    print(json.dumps(metrics, indent=2))
    print(f"Model saved -> {MODEL_PATH}")


if __name__ == "__main__":
    main()
