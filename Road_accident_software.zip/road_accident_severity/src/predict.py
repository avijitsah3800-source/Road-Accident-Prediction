"""Inference + prevention engine (counterfactual what-if analysis)."""
import joblib
import numpy as np
import pandas as pd

from .config import FEATURES, MODEL_PATH, SEVERITY_LABELS
from .data import add_derived

_model = None


def get_model():
    global _model
    if _model is None:
        _model = joblib.load(MODEL_PATH)
    return _model


def _frame(case: dict) -> pd.DataFrame:
    return add_derived(pd.DataFrame([case]))[FEATURES]


def predict(case: dict) -> dict:
    """Class probabilities, predicted label and a 0-100 severity index."""
    proba = get_model().predict_proba(_frame(case))[0]
    index = float(proba @ np.array([0, 40, 100]))   # fatal weighted most
    return {
        "label": SEVERITY_LABELS[int(np.argmax(proba))],
        "probabilities": {SEVERITY_LABELS[i]: float(p) for i, p in enumerate(proba)},
        "severity_index": round(index, 1),
    }


def risk_band(index: float) -> str:
    return "LOW" if index < 20 else "MODERATE" if index < 45 else "HIGH" if index < 70 else "CRITICAL"


def prevention_advice(case: dict) -> list[dict]:
    """Change one controllable factor at a time and measure how much the
    predicted severity drops. The last row is the 'best case scenario'."""
    base = predict(case)["severity_index"]
    out = []

    def test(title, change, applies=True):
        if applies:
            idx = predict({**case, **change})["severity_index"]
            out.append({"action": title, "new_index": idx, "reduction": round(base - idx, 1)})

    speed, limit = case["actual_speed"], case["speed_limit"]
    test(f"Drive at the speed limit ({limit} km/h) instead of {speed:.0f} km/h",
         {"actual_speed": limit}, speed > limit)
    test("Drive 20% below the limit in these conditions", {"actual_speed": limit * 0.8})
    test("Wear a seatbelt / helmet", {"seatbelt_or_helmet": 1}, case["seatbelt_or_helmet"] == 0)
    test("No alcohol involved", {"alcohol_involved": 0}, case["alcohol_involved"] == 1)
    test("Same trip in daylight", {"light_condition": "Daylight", "hour": 12},
         case["light_condition"] != "Daylight")
    test("Dry road surface (drainage, gritting, or delaying the trip)", {"road_surface": "Dry"},
         case["road_surface"] != "Dry")
    test("Safer junction design (roundabout)", {"junction": "Roundabout"},
         case["junction"] in ("T-junction", "Crossroads"))

    best = {**case, "actual_speed": min(speed, limit), "seatbelt_or_helmet": 1, "alcohol_involved": 0}
    best_idx = predict(best)["severity_index"]
    out = sorted([s for s in out if s["reduction"] > 0.5], key=lambda s: -s["reduction"])
    out.append({"action": "BEST CASE: speed legal + belt/helmet worn + sober",
                "new_index": best_idx, "reduction": round(base - best_idx, 1)})
    return out


if __name__ == "__main__":
    example = dict(road_type="Single carriageway", weather="Rain", light_condition="Dark - unlit",
                   road_surface="Wet", vehicle_type="Motorcycle", area_type="Rural",
                   junction="T-junction", speed_limit=60, actual_speed=85, num_vehicles=2,
                   driver_age=24, hour=23, day_of_week=5, alcohol_involved=1,
                   seatbelt_or_helmet=0, pedestrian_involved=0)
    r = predict(example)
    print(r, risk_band(r["severity_index"]))
    for s in prevention_advice(example):
        print(f"  -{s['reduction']:5.1f} pts  {s['action']}  (-> {s['new_index']})")
