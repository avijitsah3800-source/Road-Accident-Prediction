"""Shared configuration: feature definitions, severity scale, paths."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = ROOT / "data" / "accidents.csv"
MODEL_PATH = ROOT / "models" / "severity_model.joblib"
REPORT_DIR = ROOT / "reports"

TARGET = "severity"
SEVERITY_LABELS = {0: "Minor", 1: "Serious", 2: "Fatal"}

CATEGORICAL = ["road_type", "weather", "light_condition", "road_surface",
               "vehicle_type", "area_type", "junction"]
NUMERIC = ["speed_limit", "actual_speed", "num_vehicles", "driver_age", "hour",
           "day_of_week", "alcohol_involved", "seatbelt_or_helmet",
           "pedestrian_involved", "is_night", "is_rush_hour", "is_weekend"]
FEATURES = CATEGORICAL + NUMERIC

CHOICES = {
    "road_type": ["Single carriageway", "Dual carriageway", "Motorway", "Roundabout", "Slip road"],
    "weather": ["Clear", "Rain", "Fog", "Snow", "High winds"],
    "light_condition": ["Daylight", "Dark - lit", "Dark - unlit"],
    "road_surface": ["Dry", "Wet", "Icy", "Flooded"],
    "vehicle_type": ["Car", "Motorcycle", "Truck", "Bus", "Bicycle", "Auto-rickshaw"],
    "area_type": ["Urban", "Rural"],
    "junction": ["None", "T-junction", "Crossroads", "Roundabout"],
}
